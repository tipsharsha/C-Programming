#include <stdio.h>
void main()
{
    int n, i;
    printf("Enter your number : ");
    scanf("%d", &n);
    while (n > 0)
    {
        i = n % 10;
        if (i != 0 && i != 1)
        {
            printf("It is not a binary");
            break;
        }
        n = n / 10;
        if (n == 0)
        {
            printf("It is a binary");
        }
    }
}