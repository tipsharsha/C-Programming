#include <stdio.h>
#include <math.h>
int main()
{
    int n,i,j,pairs;
    printf("Enter your possible taxicab number : ");
    scanf("%d", &n);
    pairs = 0;
    j = 1;
    while(j<pow(n,1/3.0))
    {
        i = 1;
        while(i<j-1)
        {
            if(i*i*i+j*j*j == n)
            {
              pairs++;
              printf("Set%d of pair of cubes is %d and %d \n",pairs,j,i);
            }
             i++;
        }
       j++;
    }
    if (pairs != 0)
    {
      printf("it is a taxicab number and above are pairs of cubes\n");
    }
    else
    {
      printf("it is not a texicab number\n");
    }
    printf("total number of pairs is %d", pairs);
    return 0;
}