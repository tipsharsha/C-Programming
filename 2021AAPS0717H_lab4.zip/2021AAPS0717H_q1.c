#include <stdio.h>
int main() {
   int rows,pas = 1, s, i, j;
   //s is for the gap from start to the start of the row//
   printf("Enter the number of rows: ");
   scanf("%d", &rows);
   for (i = 0; i < rows; i++)
    {
      for (s = 1; s <= rows - i; s++)
         printf("  ");
      for (j = 0; j <= i; j++) 
      {
         if (j == 0 || i == 0)
            pas = 1;
         else
            pas = pas*(i - j + 1) / j;
         printf("%4d", pas);
      }
      printf("\n");
    }
   return 0;
}