// Id : 2021AAPS0717H Sriharsha Tippavajhala//

#include <stdio.h>
int main()
{
    while (printf("Sriharsha Tippavajhala"))
        // the program runs through the while loop and checks for a condition and prints the name, taking condition as 0 and breaks//
        return 0;
}