// Id : 2021AAPS0717H Sriharsha Tippavajhala//

#include <stdio.h>
void main()
{
    int k;
    // defining c as int so teh user input takes a integer//
    printf("Enter the ASCII value : ");
    scanf("%d", &k);
    // as c is an integer value given till here it is given as ASCII value of some character as user's input//
    printf("That is the ASCII value of %c", k);
    // As charcters are stored in form of ASCII values we use the int value we took to print the ASCII character of the given value of the user//
}